var assert = require('assert');

describe('align-items', function () {

  /**
   * If you want to test this code, comment 'alignItems.result' from align-items.js
   */
  // it('should return start', function (done) {
  //   test.alignItems.ms('flex-start', 'start', done);
  // });

});
