var assert = require('assert');

describe('flex-direction', function () {

  /**
   * If you want to test this code, comment 'flexDirection.result' from flex-direction.js
   */
  // it('should return horizontal', function (done) {
  //   test.flexDirection.moz('row', 'horizontal', done);
  // });

  // it('should return the same value', function (done) {
  //   test.flexDirection.oldestwebkit('column-reverse', 'reverse', done);
  // });

});