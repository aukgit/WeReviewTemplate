var assert = require('assert');

describe('flex-shrink', function () {

  it('should return the same value', function (done) {
    test.flexShrink('something', 'something', done);
  });

});