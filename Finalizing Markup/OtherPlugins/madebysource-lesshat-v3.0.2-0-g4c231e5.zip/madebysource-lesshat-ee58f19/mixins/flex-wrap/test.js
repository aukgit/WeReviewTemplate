var assert = require('assert');

describe('flex-wrap', function () {

  it('should return the same value', function (done) {
    test.flexWrap('wrap-reverse', 'wrap-reverse', done);
  });

});