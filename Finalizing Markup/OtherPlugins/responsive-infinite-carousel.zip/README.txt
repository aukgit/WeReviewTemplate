A Pen created at CodePen.io. You can find this one at http://codepen.io/lucasmotta/pen/ujKbF.

 This is an in-progress experiment to create a infinite (circular) responsive carousel.
That means:
– You can resize as much as you want.
- You can scroll as much as you want.

Simple as that. But so far the width of each item is still hardcoded on the CSS - I'm looking for a nice solution before going for js.